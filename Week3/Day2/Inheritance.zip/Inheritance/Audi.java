package week3.day2;

public class Audi extends Car{

	public void highBrakingSystem() {
		System.out.println("highBrakingSystem");

	}
	
	
}
