package week3.day2;
//           SuperClass/BaseClass
public class ParentClass {

	public void takePhoto() {
		System.out.println("Photo was taken");
}

	public static void main(String[] args) {
		ParentClass mobileOptions=new ParentClass();
		mobileOptions.takePhoto();
	}
	
	
	
}
