package steps;

import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.testng.AbstractTestNGCucumberTests;

public class BaseClass extends AbstractTestNGCucumberTests{
	public static EdgeDriver driver;
	
	@BeforeMethod
	public void preConditions() {
	 driver=new EdgeDriver();
	 driver.get("http://leaftaps.com/opentaps/control/main");
	 driver.manage().window().maximize();
	}
	@AfterMethod
	public void postConditions() {
		driver.close();

	}
}
