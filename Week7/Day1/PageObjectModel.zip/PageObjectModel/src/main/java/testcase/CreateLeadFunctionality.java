package testcase;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class CreateLeadFunctionality extends BaseClass {
	
	@Test
	public void runCreateLead() {
		
    LoginPage lp=new LoginPage();
    lp.enterUsername()
    .enterPassword()
    .clickLoginButton()
    .clickCrmsfa()
    .clickLeadsLink()
    .clickCreateLeadLink()
    .enterCompanyName()
    .enterFirstName()
    .enterLastName()
    .clickCreateLeadButton()
    .verifyLead();
    
	}
	

}
