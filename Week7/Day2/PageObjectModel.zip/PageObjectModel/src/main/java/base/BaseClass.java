package base;

import java.io.IOException;

import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utils.ReadExcel;



public class BaseClass {

	public EdgeDriver driver;
	
	public String filename;
	
	@BeforeMethod
	public void preCondition() {
		driver=new EdgeDriver();
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().window().maximize();
		

	}
	@AfterMethod
	public void postCondition() {
		driver.close();

	}
	
	@DataProvider(name="fetch")
	public String[][] setDatas() throws IOException {

		String[][] readData = ReadExcel.readData(filename);  //EditLead
		return readData;
	}
	
	
	
	
}
