package base;

import java.io.IOException;

import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;



public class BaseClass extends AbstractTestNGCucumberTests {

	//public EdgeDriver driver;
	private static final ThreadLocal<EdgeDriver> driver= new ThreadLocal<>();
	public String filename;
	public void setDriver() {
		
		driver.set(new EdgeDriver());
	}
	
	public EdgeDriver getDriver() {
		EdgeDriver edgeDriver = driver.get();
		return edgeDriver;
	}
	
	
	
	@BeforeMethod
	public void preCondition() {
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps");
		getDriver().manage().window().maximize();
		

	}
	@AfterMethod
	public void postCondition() {
		getDriver().close();

	}
	
	@DataProvider(name="fetch")
	public String[][] setDatas() throws IOException {

		String[][] readData = ReadExcel.readData(filename);  //EditLead
		return readData;
	}
	
	
	
	
}
