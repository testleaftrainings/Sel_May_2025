package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass{
	

	@And("Enter the companyname as (.*)$")
	public CreateLeadPage enterCompanyName(String company) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(company);
        return this;
	}
	@And("Enter the firstname as (.*)$")
	public CreateLeadPage enterFirstName(String firstName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
        return this;
	}
	@And("Enter the lastname as (.*)$")
	public CreateLeadPage enterLastName(String lastName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
        return this;
	}
	@When("click on the CreateLead button")
	public ViewLeadPage clickCreateLeadButton() {
		getDriver().findElement(By.name("submitButton")).click();
         return new ViewLeadPage();
	}

}
