package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {
	
	
	@And("Enter the username as {string}")
	public LoginPage enterUsername(String username) throws IOException {
		getDriver().findElement(By.xpath("//input[@id='username']")).sendKeys(username);
		reportStep("Pass", "Username enterted successfully");
        return this;
	}
	
	@And("Enter the password as {string}")
	public LoginPage enterPassword(String password) throws IOException {
		getDriver().findElement(By.id("password")).sendKeys(password);
		reportStep("Pass", "Password enterted successfully");
         return this;
	}
	
	@When("Click on the Login button")
	public WelcomePage clickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
        //WelcomePage wp=new WelcomePage();
        //return wp;
		return new WelcomePage(); //abc
	}

}
