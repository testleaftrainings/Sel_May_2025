package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass {


@Then("It should naviage to the next page")
public void login() {
	System.out.println("Login successful");

}
@But("It throws the error message")
public void invalidLogin() {
	// TODO Auto-generated method stub

}



	@When("Click on the Crmsfa link")
	public MyHomePage clickCrmsfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
        return new MyHomePage();
	}

}
